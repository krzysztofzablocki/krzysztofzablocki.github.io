func caloriesForWeight(kgs: Double) -> Double {
  return kgs * 7700
}
