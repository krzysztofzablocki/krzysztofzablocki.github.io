enum Gender {
  case Male
  case Female
}

typealias User = (gender: Gender, age: Int, weightInKg: Double, heightInCm: Int, bodyfat: Int?)
