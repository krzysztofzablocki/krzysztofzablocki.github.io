func dailyCalories(tdee: Int, #goal: Goal) -> Int {
  return Int(Double(tdee) + (caloriesForWeight(goal())))
}

let target = dailyCalories(tdee, goal: bulking(kgPerWeek: 0.2))
println("You should be eating \(target) kcal everyday")
