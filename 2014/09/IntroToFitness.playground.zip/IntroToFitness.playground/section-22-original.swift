typealias Goal = () -> Double
func bulking(#kgPerWeek: Double) -> Goal {
  return {+kgPerWeek/7}
}
func cutting(#kgPerWeek: Double) -> Goal {
  return {-kgPerWeek/7}
}
