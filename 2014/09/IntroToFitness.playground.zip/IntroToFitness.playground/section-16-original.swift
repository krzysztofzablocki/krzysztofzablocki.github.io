user = User(gender: .Male, age: 26, weightInKg: 73, heightInCm: 184, bodyfat: 10)
let tdee = TDEE(BMRCalculatorForUser(user), ActivityFactor.Sedentary)
println("You can maintain your weight by eating \(tdee) kcal daily")
