var user = User(gender: .Male, age: 26, weightInKg: 73, heightInCm: 184, bodyfat: 10)
