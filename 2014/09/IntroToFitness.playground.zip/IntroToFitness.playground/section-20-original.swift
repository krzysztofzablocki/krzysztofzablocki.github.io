println("daily deficit: \(caloriesForWeight(0.5) / 7.0)")
