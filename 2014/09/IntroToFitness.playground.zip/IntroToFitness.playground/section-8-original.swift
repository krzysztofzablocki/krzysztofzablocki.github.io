typealias BMRCalculator = () -> Double
