func lbm(user: User) -> Double {
  return user.weightInKg * (100.0-Double(user.bodyfat!))/100.0
}

func BMRCalculatorForUser(user: User) -> BMRCalculator {
  func cunninghamCalculator(user: User) -> BMRCalculator {
    return { 500 + 22 * lbm(user) }
  }
  
  func mifflinCalculator(user: User) -> BMRCalculator {
    let genderAdjustment = user.gender == .Male ? 161.0 : -5.0
    return { 10.0 * user.weightInKg + 6.25 * Double(user.heightInCm) + genderAdjustment }
  }
  
  if let bodyfat = user.bodyfat {
    return cunninghamCalculator(user)
  }
  return mifflinCalculator(user)
}
