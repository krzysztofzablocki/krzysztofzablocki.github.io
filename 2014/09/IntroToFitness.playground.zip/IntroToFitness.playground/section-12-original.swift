func TDEE(bmrCalculator: BMRCalculator, activityFactor: ActivityFactor) -> Int {
  return Int(bmrCalculator() * activityFactor.rawValue)
}
