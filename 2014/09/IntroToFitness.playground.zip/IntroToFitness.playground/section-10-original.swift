enum ActivityFactor: Double {
  case Sedentary = 1.2 // Little or no exercise and desk job
  case LightlyActive = 1.375 // Light exercise or sports 1-3 days a week
  case ModeratelyActive = 1.55 // Moderate exercise or sports 3-5 days a week
  case VeryActive = 1.725 // Hard exercise or sports 6-7 days a week4
  case ExtremelyActive = 1.9 // Hard daily exercise or sports and physical job
}
