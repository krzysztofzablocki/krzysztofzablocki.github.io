func toKg(#lbs: Double) -> Double {
  return lbs / 2.2
}

func toCm(#feet: Double, #inches: Double) -> Double {
  return feet * 30.48 + inches * 2.54
}
