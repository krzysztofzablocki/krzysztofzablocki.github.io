//: Playground - noun: a place where people can play

import UIKit
import XCPlayground
import QuartzCore

class Animator {
    class TargetProxy {
        init (target: Animator) {
            self.target = target
        }
        
        weak var target: Animator!
        var totalTime: NSTimeInterval = 0
        
        @objc func onFire (dl: CADisplayLink) {
            totalTime += dl.duration
            target.block(totalTime)
        }
    }
    
    
    private lazy var displayLink: CADisplayLink = {
        return CADisplayLink(target: TargetProxy(target: self), selector: "onFire:")
    }()
    private let block: NSTimeInterval -> Void

    init (block: NSTimeInterval -> Void) {
        self.block = block
        displayLink.addToRunLoop(NSRunLoop.mainRunLoop(), forMode: NSRunLoopCommonModes)
    }
    
    deinit {
        displayLink.invalidate()
    }
}




func createBlobShape() -> UIBezierPath {
    let ovalPath = UIBezierPath()
    ovalPath.moveToPoint(CGPointMake(13.71, -29.07))
    ovalPath.addCurveToPoint(CGPointMake(27.92, -14), controlPoint1: CGPointMake(20.64, -25.95), controlPoint2: CGPointMake(24.57, -20.72))
    ovalPath.addCurveToPoint(CGPointMake(33, 0.5), controlPoint1: CGPointMake(30.08, -9.68), controlPoint2: CGPointMake(33, -4.64))
    ovalPath.addCurveToPoint(CGPointMake(20.82, 26), controlPoint1: CGPointMake(33, 10.93), controlPoint2: CGPointMake(27.47, 17.84))
    ovalPath.addCurveToPoint(CGPointMake(0, 33), controlPoint1: CGPointMake(16.02, 31.88), controlPoint2: CGPointMake(7.63, 33))
    ovalPath.addCurveToPoint(CGPointMake(-16.72, 28.33), controlPoint1: CGPointMake(-6.21, 33), controlPoint2: CGPointMake(-11.89, 31.29))
    ovalPath.addCurveToPoint(CGPointMake(-23.86, 22), controlPoint1: CGPointMake(-19.59, 26.57), controlPoint2: CGPointMake(-22.22, 24.28))
    ovalPath.addCurveToPoint(CGPointMake(-28, 17), controlPoint1: CGPointMake(-25.19, 20.16), controlPoint2: CGPointMake(-26.74, 19.46))
    ovalPath.addCurveToPoint(CGPointMake(-33, 0.5), controlPoint1: CGPointMake(-30.24, 12.61), controlPoint2: CGPointMake(-33, 5.74))
    ovalPath.addCurveToPoint(CGPointMake(-23.86, -23), controlPoint1: CGPointMake(-33, -9.63), controlPoint2: CGPointMake(-31.23, -17.04))
    ovalPath.addCurveToPoint(CGPointMake(-4.57, -33), controlPoint1: CGPointMake(-18.17, -27.6), controlPoint2: CGPointMake(-12.51, -33))
    ovalPath.addCurveToPoint(CGPointMake(13.71, -29.07), controlPoint1: CGPointMake(0.32, -33), controlPoint2: CGPointMake(9.53, -30.95))
    ovalPath.closePath()
    return ovalPath
}

func toRadian(degree: Int) -> Float {
    return Float(Double(degree) * (M_PI / 180.0))
}

let blob = CAShapeLayer()
let blobShape = createBlobShape()
blob.path = blobShape.CGPath
blob.frame = blobShape.bounds
blob.anchorPoint = CGPointMake(0, 0)
blob.fillColor = UIColor.orangeColor().CGColor


var view = UIView(frame: CGRectMake(0, 0, 640, 480))
view.backgroundColor = UIColor.grayColor().colorWithAlphaComponent(0.8)
XCPlaygroundPage.currentPage.liveView = view

blob.position = view.center
view.layer.addSublayer(blob)

let playImageView = UIImageView(image: UIImage(named: "play"))
playImageView.transform = CGAffineTransformMakeScale(0.05, 0.05)
playImageView.center = blob.position
view.addSubview(playImageView)

XCPlaygroundPage.currentPage.needsIndefiniteExecution = true

let dl = Animator {
    let skewBaseTime = $0 * 0.3

    let rotation = CATransform3DMakeRotation(CGFloat(acos(cos(skewBaseTime))), 0, 0, 1)
    let upscale = 5.0
    let scaleAdjustment = 0.1
    let scale = CATransform3DMakeScale(CGFloat(upscale + abs(sin(skewBaseTime) * scaleAdjustment)), CGFloat(upscale + abs(cos(skewBaseTime) * scaleAdjustment)), 1)
    
    let skewTransform = CGAffineTransformMake(1.0, 0.0, CGFloat(cos(skewBaseTime + M_PI_2) * 0.1), 1.0, 0.0, 0.0)
    CATransaction.begin()
    CATransaction.setValue(kCFBooleanTrue, forKey: kCATransactionDisableActions)
    view.layer.sublayerTransform = CATransform3DConcat(CATransform3DMakeAffineTransform(skewTransform), scale)
    blob.transform = rotation
    CATransaction.commit()
}
