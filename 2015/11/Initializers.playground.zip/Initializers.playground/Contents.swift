//: Playground - noun: a place where people can play

import UIKit


class Foo {
    private let window: UIWindow
    private let controller: UIViewController
    
    init() {
        controller = UIStoryboard(name: "Main", bundle: nil).instantiateInitialViewController()!
        
        window = UIWindow(frame: UIScreen.mainScreen().bounds)
        window.backgroundColor = UIColor.whiteColor()
        window.makeKeyAndVisible()
    }
}

//class Foo2 {
//    private let window: UIWindow
//    private let controller: UIViewController
//    
//    init() {
//        controller = setupController()
//        window = setupWindow()
//    }
//    
//    private func setupController() -> UIViewController {
//        return UIStoryboard(name: "Main", bundle: nil).instantiateInitialViewController()!
//    }
//    
//    private func setupWindow() -> UIWindow {
//        UIWindow(frame: UIScreen.mainScreen().bounds)
//        window.backgroundColor = UIColor.whiteColor()
//        window.makeKeyAndVisible()
//        return window
//    }
//}

class Foo3 {
    init() {
        let _ = controller
        let _ = window
    }
    
    private lazy var controller: UIViewController = {
        return UIStoryboard(name: "Main", bundle: nil).instantiateInitialViewController()!
    }()
    
    private lazy var window: UIWindow = {
        let window = UIWindow(frame: UIScreen.mainScreen().bounds)
        window.backgroundColor = UIColor.whiteColor()
        window.makeKeyAndVisible()
        return window
    }()
}


