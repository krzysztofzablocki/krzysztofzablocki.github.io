import UIKit

protocol CoreDataStack {}
protocol Provider {}
protocol Report {}

struct IntegrationService {
  let provider: Provider
  init(provider: Provider, map: Report -> Void) {
    self.provider = provider
  }
}

struct MFPService: Provider {}

struct FlowController {
  let coreDataStack: CoreDataStack
  let rootViewController = UIViewController()
}

struct CoreDataReportProcessor {
  let stack: CoreDataStack
  func processReports(_: Report) {}
}

// Option lazy var's with side-effects (;[)

class Foo_lazy {
  let coreDataStack: CoreDataStack
  let mfpService = MFPService()
  
  init(coreDataStack stack: CoreDataStack) {
    coreDataStack = stack
    let _ = integrator
    let _ = rootFlowController
    let _ = window
  }
  
  lazy var rootFlowController: FlowController = {
    return FlowController(coreDataStack: self.coreDataStack)
  }()
  
  lazy var window: UIWindow = {
    let window = UIWindow(frame: UIScreen.mainScreen().bounds)
    window.backgroundColor = UIColor.whiteColor()
    window.rootViewController = self.rootFlowController.rootViewController
    window.makeKeyAndVisible()
    return window
  }()
  
  
  lazy var integrator: IntegrationService = {
    let coreDataProcessor = CoreDataReportProcessor(stack: self.coreDataStack)
    let integrator = IntegrationService(provider: self.mfpService) {
      coreDataProcessor.processReports($0)
    }
    return integrator
  }()
}

// Option private extension static functions

class Foo_ext {
  let coreDataStack: CoreDataStack
  let mfpService = MFPService()
  let integrator: IntegrationService
  let flowController: FlowController
  let window: UIWindow
  
  init(coreDataStack stack: CoreDataStack) {
    coreDataStack = stack
    integrator = Foo_ext.SetupIntegrator(stack, provider: self.mfpService)
    flowController = Foo_ext.SetupFlowController(stack)
    window = Foo_ext.SetupWindow(self.flowController.rootViewController)
  }
}

private extension Foo_ext {
  static func SetupIntegrator(stack: CoreDataStack, provider: Provider) -> IntegrationService {
    let coreDataProcessor = CoreDataReportProcessor(stack: stack)
    let integrator = IntegrationService(provider: provider) {
      coreDataProcessor.processReports($0)
    }
    return integrator
  }
  
  static func SetupFlowController(stack: CoreDataStack) -> FlowController {
    return FlowController(coreDataStack: stack)
  }
  
  static func SetupWindow(controller: UIViewController) -> UIWindow {
    let window = UIWindow(frame: UIScreen.mainScreen().bounds)
    window.backgroundColor = UIColor.whiteColor()
    window.rootViewController = controller
    window.makeKeyAndVisible()
    return window
  }
}


