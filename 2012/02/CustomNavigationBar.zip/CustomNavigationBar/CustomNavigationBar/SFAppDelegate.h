//
//  SFAppDelegate.h
//  CustomNavigationBar
//
//  Created by Krzysztof Zabłocki on 2/21/12.
//  Copyright (c) 2012 Krzysztof Zabłocki. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SFAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
