//
//  NSObject+SFExecuteOnDealloc.h
//  SampleProject
//
//  Created by Krzysztof Zabłocki on 2/28/12.
//  Copyright (c) 2012 Krzysztof Zabłocki. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (SFExecuteOnDealloc)
- (void)sf_performBlockOnDealloc:(void(^)(void))aBlock;
@end
