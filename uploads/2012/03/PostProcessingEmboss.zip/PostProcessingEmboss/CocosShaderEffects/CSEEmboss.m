//
//  CSEEmboss.m
//  CocosShaderEffects
//
//  Created by Ray Wenderlich on 3/20/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "CSEEmboss.h"

@implementation CSEEmboss {
  CCSprite *sprite;  //1
  int timeUniformLocation;
  float totalTime;
  
  CCRenderTexture *renderTexture;
}

- (id)init
{
  self = [super init];
  if (self) {
    // 1
    sprite = [CCSprite spriteWithFile:@"Default.png"];
    sprite.anchorPoint = CGPointZero;
    sprite.rotation = 90;
    sprite.position = ccp(0, 320);
    [self addChild:sprite];
    
    CGSize size = [CCDirector sharedDirector].winSize;
    renderTexture = [[CCRenderTexture alloc] initWithWidth:size.width height:size.height pixelFormat:kCCTexture2DPixelFormat_RGB888];
    
    // 2
    const GLchar * fragmentSource = (GLchar*) [[NSString stringWithContentsOfFile:[CCFileUtils fullPathFromRelativePath:@"CSEEmboss.fsh"] encoding:NSUTF8StringEncoding error:nil] UTF8String];
    renderTexture.sprite.shaderProgram = [[CCGLProgram alloc] initWithVertexShaderByteArray:ccPositionTextureA8Color_vert
                                                                    fragmentShaderByteArray:fragmentSource];
    [renderTexture.sprite.shaderProgram addAttribute:kCCAttributeNamePosition index:kCCVertexAttrib_Position];
    [renderTexture.sprite.shaderProgram addAttribute:kCCAttributeNameTexCoord index:kCCVertexAttrib_TexCoords];
    [renderTexture.sprite.shaderProgram link];
    [renderTexture.sprite.shaderProgram updateUniforms];
    renderTexture.sprite.position = ccp(0, 0);
    renderTexture.sprite.anchorPoint = ccp(0, 1);

    // 3
		timeUniformLocation = glGetUniformLocation(renderTexture.sprite.shaderProgram->program_, "u_time");
    
		// 4
		[self scheduleUpdate];
    
    // 5
    [renderTexture.sprite.shaderProgram use];
    
    
  }
  return self;
}

- (void)update:(float)dt
{
  totalTime += dt;
  [renderTexture.sprite.shaderProgram use];
  glUniform1f(timeUniformLocation, totalTime);
}

- (void)visit
{
  [renderTexture beginWithClear:0 g:0 b:0 a:1];
  [super visit];
  [renderTexture end];
  [renderTexture.sprite visit];
}

@end
